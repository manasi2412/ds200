
import pandas as pd
import matplotlib.pyplot as plt
import sys
#create dataframe
df=pd.read_csv(sys.argv[1], header=0)

#plot line plot with first column of dataframe as x values and second column as y values
plt.plot(df['Year of  expiry'],df['No. of  Leases'],color='#dd12dd',label="No. of  Leases")
plt.plot(df['Year of  expiry'],df['Lease area (Hect.)'],color='#caabdd',label="Lease area (Hect.)")
# plt.scatter(Mem['col3'],Mem['col4'],color='#caabdd',label="Hop6")

#specifying labels
plt.xlabel("Year of Expiry")
plt.ylabel("Value")

#enable legend
plt.legend()
plt.show()

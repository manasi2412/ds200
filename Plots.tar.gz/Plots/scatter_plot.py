import pandas as pd
import matplotlib.pyplot as plt
import sys
#create dataframe
df=pd.read_csv(sys.argv[1], header=0)

#plot scatter with first column as x values and second column as y values
plt.scatter(df['Year of  expiry'],df['No. of  Leases'],color='#dd12dd',label="Data points")

#specifying labels
plt.xlabel("Year of Expiry")
plt.ylabel("No. of Leases")

#enable legend
plt.legend()
plt.show()

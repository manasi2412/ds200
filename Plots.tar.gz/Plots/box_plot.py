
import pandas as pd
import matplotlib.pyplot as plt
import sys
#create dataframe from csv
df=pd.read_csv(sys.argv[1], header=0)
plotMap=[]

#create a list of lists where each list will have a corresponding box plot

plotMap.append(df['Population_2001'].dropna().tolist())
plotMap.append(df['Population_2011'].dropna().tolist())
#plotting
plt.boxplot(plotMap)

#specifying labels
plt.xticks([1,2],["2001","2011"])
plt.xlabel("Year")
plt.ylabel("Population")


plt.legend()
plt.show()
